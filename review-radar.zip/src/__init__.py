﻿"""
ReviewRadar: E-Commerce Fake Review & Bot Detector.
A hybrid Classical NLP and LLM Forensic Detection Engine.
"""

__version__ = "1.0.0"
__author__ = "ReviewRadar Team"
